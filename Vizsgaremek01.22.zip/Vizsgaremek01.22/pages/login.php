<div id="login">
    <div id="bg"></div>

    <form method="post" action="login.php">
        <div class="form-field">
            <input type="text" name="username" placeholder="Felhasználónév" required/>
        </div>

        <div class="form-field">
            <input type="password" name="password" placeholder="Jelszó" required/>
        </div>

        <div class="form-field">
            <button class="btn" type="submit" name="login" value="1">Bejelentkezés</button>
        </div>
    </form>

    <a href="index.php?menu=register"><p>Még nem regisztráltál?</p></a>
</div>