<?php

class Database {

    private $db = null;
    public $error = false;

    public function __construct($host, $username, $pass, $db) {
        try {
            $this->db = new mysqli($host, $username, $pass, $db);
            $this->db->set_charset("utf8");
        } catch (Exception $exc) {
            $this->error = true;
            echo '<p>Az adatbázis nem elérhető!</p>';
            exit();
        }
    }

    public function osszesAuto() {
        $result = $this->db->query("SELECT * FROM `jarmuvek`");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getAuto($id) {
        $result = $this->db->query("SELECT * FROM `jarmuvek` WHERE id = " . $id);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getKiemeltAjanlatok() {
        $result = $this->db->query("SELECT * FROM `jarmuvek`");
        return $result->fetch_all(MYSQL_ASSOC);
    }

public function login($username, $password) {
        try {
            $stmt = $this->db->prepare("SELECT id, username, password FROM users WHERE username = ?");
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $this->db->error);
            }

            $stmt->bind_param("s", $username);
            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }

            $stmt->bind_result($user_id, $db_username, $db_password);
            $stmt->fetch();
            $stmt->close();

            if ($db_username) {
                if (password_verify($password, $db_password)) {
                    session_start();
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['username'] = $db_username;
                    $this->locationredirect("index.php?menu=fooldal"); // Módosítás itt
                } else {
                    throw new Exception("Incorrect password.");
                }
            } else {
                throw new Exception("User not found.");
            }
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    private function redirect($location) {
        echo "<script>alert('Sikeres bejelentkezés!'); window.location.href='{$location}';</script>";
        exit();
    }


    public function register($email, $username, $password) {
        $password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and bind the SQL statement 
        $stmt = $this->db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password);

// Execute the SQL statement 
        if ($stmt->execute()) {
            echo "New account created successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

// Close the connection 
        $stmt->close();
    }
}
